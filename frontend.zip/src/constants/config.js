export const BASE_URL = "Your_backend_url"
